import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  standalone: true
})
export class CalculatorComponent {
  form: FormGroup;
  result: any;

  constructor(private fb: FormBuilder, private http: HttpClient) {
    this.form = this.fb.group({
      fuelUsed: [0],
      electricityUsed: [0]
    });
  }

  onSubmit() {
    this.http.post(`${environment.apiUrl}/carbon/calculate`, this.form.value)
      .subscribe({
        next: (res) => this.result = res,
        error: (err) => console.error('Calculation error', err)
      });
  }
}