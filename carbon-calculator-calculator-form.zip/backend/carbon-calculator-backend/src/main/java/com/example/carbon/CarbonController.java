package com.example.carbon;

import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/carbon")
public class CarbonController {

    @PostMapping("/calculate")
    public Map<String, Object> calculate(@RequestBody Map<String, Double> body) {
        double fuelUsed = body.getOrDefault("fuelUsed", 0.0);          // in liters
        double electricityUsed = body.getOrDefault("electricityUsed", 0.0); // in kWh

        double fuelEmissions = fuelUsed * 2.31;           // 2.31 kg CO2 per liter (gasoline)
        double electricityEmissions = electricityUsed * 0.233; // 0.233 kg CO2 per kWh (average)

        double totalCO2 = fuelEmissions + electricityEmissions;

        return Map.of("totalCO2", Math.round(totalCO2 * 100.0) / 100.0);
    }
}